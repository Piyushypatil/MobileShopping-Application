package com.example.admin.mobomark;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Recharge extends AppCompatActivity {
    ImageButton paytm;
    ImageButton phpe;
    ImageButton jio;
    ImageButton mobi;
    ImageButton free;
    ImageButton air;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recharge);
        paytm=(ImageButton)findViewById(R.id.linkPaytm);
        phpe=(ImageButton)findViewById(R.id.linkPhone);
        jio=(ImageButton)findViewById(R.id.jio);
        mobi=(ImageButton)findViewById(R.id.Mobi);
        free =(ImageButton) findViewById (R.id.freech);
        air =(ImageButton) findViewById (R.id.air);

        paytm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(Recharge.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.paytm.com");
                startActivity(webviewIntent);
            }
        });
        phpe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(Recharge.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.phonepe.com");
                startActivity(webviewIntent);

            }
        });
        jio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(Recharge.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.jio.com");
                startActivity(webviewIntent);

            }
        });
        mobi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(Recharge.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.mobikwik.com");
                startActivity(webviewIntent);

            }
        });
        free.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(Recharge.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.freecharge.in");
                startActivity(webviewIntent);

            }
        });
        air.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(Recharge.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.airtel.in");
                startActivity(webviewIntent);

            }
        });
    }
}
