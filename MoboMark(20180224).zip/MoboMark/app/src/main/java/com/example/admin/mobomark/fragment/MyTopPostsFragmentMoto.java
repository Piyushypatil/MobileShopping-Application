package com.example.admin.mobomark.fragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public class MyTopPostsFragmentMoto extends PostListFragment {

    public MyTopPostsFragmentMoto() {}

    @Override
    public Query getQuery(DatabaseReference databaseReference) {
        // [START my_top_Mobiles_query]
        // My top Mobiles by number of stars
        String myUserId = getUid();

        Query topMobiles = databaseReference.child("mobiles").child ("Moto").orderByChild ("starCount");
       // Query myTopMobilesQuery = databaseReference.child("Moto").orderByChild("starCount");
        // [END my_top_Mobiles_query]

        return topMobiles;
    }
    @Override
    public String getBrand() {
        return "Moto";
    }
}
