package com.example.admin.mobomark;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.mobomark.models.Lenovo;
import com.example.admin.mobomark.models.Mobile;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class PostDetailActivityLenovo extends NewPostActivity {

    private static final String TAG = "PostDetailActivityLenovo";

    public static final String EXTRA_POST_KEY = "post_key";

    private DatabaseReference mPostReference;
    private DatabaseReference mCommentsReference;
    private ValueEventListener mPostListener;
    private String mPostKey;
    private ImageView imgv;
    private TextView mAuthorView;
    private TextView mTitleView;
    private TextView mBodyView;
    private TextView mBodyView1;
    private TextView mBodyView2;
    private TextView mPriceView;
    private TextView mAmazon;
    private TextView mFlipcart;
    private TextView mShopclues;
    private TextView mEbay;
    private TextView mSnapdeal;
    private EditText mflipurl;
    private EditText mamazonurl;
    private EditText mShopcluesurl;
    private EditText mEbayurl;
    private EditText mSnapdealurl;
    private EditText mCommentField;
    private Button mCommentButton;
    private RecyclerView mCommentsRecycler;
    ImageButton flipcart;
    ImageButton amazon;
    ImageButton Shopclues;
    ImageButton Ebay;
    ImageButton Snapdeal;
    FloatingActionButton Save;
    ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail_lenovo);
        flipcart =(ImageButton)findViewById (R.id.flipcartImg);
        amazon =(ImageButton)findViewById (R.id.amazonImg);
        Shopclues =(ImageButton)findViewById (R.id.ShopImg);
        Ebay =(ImageButton)findViewById (R.id.EbayImg);
        Snapdeal =(ImageButton)findViewById (R.id.SnapdealImg);
        flipcart.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i= new Intent (PostDetailActivityLenovo.this,Web_Url.class);
                i.putExtra ("flipurl",mflipurl.getText ().toString ());
                startActivity (i);
            }
        });
        amazon.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i2= new Intent (PostDetailActivityLenovo.this,WebAmazon.class);
                i2.putExtra ("amazonurl",mamazonurl.getText ().toString ());
                startActivity (i2);
            }
        });
        Shopclues.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i3= new Intent (PostDetailActivityLenovo.this,WebShop.class);
                i3.putExtra ("Shopcluesurl",mShopcluesurl.getText ().toString ());
                startActivity (i3);
            }
        });
        Ebay.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i4= new Intent (PostDetailActivityLenovo.this,WebEbay.class);
                i4.putExtra ("Ebayurl",mEbayurl.getText ().toString ());
                startActivity (i4);
            }
        });
        Snapdeal.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i5= new Intent (PostDetailActivityLenovo.this,WebSnap.class);
                i5.putExtra ("Snapdealurl",mSnapdealurl.getText ().toString ());
                startActivity (i5);
            }
        });
        Save= (FloatingActionButton)findViewById (R.id.fabsave);
        Save.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {

                submitPost();
                Toast.makeText(PostDetailActivityLenovo.this, "update", Toast.LENGTH_LONG).show();


            }
        });
        // Get post key from intent
        mPostKey = getIntent().getStringExtra(EXTRA_POST_KEY);
        if (mPostKey == null) {
            throw new IllegalArgumentException("Must pass EXTRA_POST_KEY");
        }

        // Initialize Database
        mPostReference = FirebaseDatabase.getInstance().getReference()
                .child("Lenovo").child(mPostKey);

        // Initialize Views
        mTitleView = findViewById(R.id.post_title);
        mBodyView = findViewById(R.id.post_body);
        mBodyView1 = findViewById(R.id.post_body1);
        mBodyView2 = findViewById(R.id.post_body2);
        mAmazon = findViewById(R.id.post_AmazonPrice);
        mFlipcart = findViewById(R.id.post_FlipPrice);
        mShopclues = findViewById(R.id.post_ShopPrice);
        mEbay = findViewById(R.id.post_EbayPrice);
        mSnapdeal = findViewById(R.id.post_SnapdealPrice);
        mPriceView = findViewById(R.id.post_price);
        mflipurl = findViewById (R.id.Url);
        mamazonurl = findViewById (R.id.url2);
        mShopcluesurl = findViewById (R.id.url3);
        mEbayurl = findViewById (R.id.url4);
        mSnapdealurl = findViewById (R.id.url5);

        imgv = findViewById(R.id.imgv);
    }

    @Override
    public void onStart() {
        super.onStart();

        // Add value event listener to the post
        // [START post_value_event_listener]
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                Lenovo post = dataSnapshot.getValue(Lenovo.class);
                // [START_EXCLUDE]
                mTitleView.setText(post.brand+" "+post.model);
                mBodyView.setText(post.specs);
                mBodyView1.setText(post.cam);
                mBodyView2.setText(post.Sto);
                mAmazon.setText(post.amazon);
                mFlipcart.setText(post.flipcart);
                mShopclues.setText(post.Shopclues);
                mEbay.setText(post.Ebay);
                mSnapdeal.setText(post.Snapdeal);
                mPriceView.setText(post.price);
                mflipurl.setText(post.flipurl);
                mamazonurl.setText (post.amazonurl);
                mShopcluesurl.setText (post.Shopcluesurl);
                mEbayurl.setText (post.Ebayurl);
                mSnapdealurl.setText (post.Snapdealurl);

                Picasso.with(getApplicationContext()).load(post.imageUrl).into(imgv);
                // [END_EXCLUDE]
            }

            @SuppressLint("LongLogTag")
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
                // [START_EXCLUDE]
                Toast.makeText(PostDetailActivityLenovo.this, "Failed to load post.",
                        Toast.LENGTH_SHORT).show();
                // [END_EXCLUDE]
            }
        };
        mPostReference.addValueEventListener(postListener);
        // [END post_value_event_listener]

        // Keep copy of post listener so we can remove it when app stops
        mPostListener = postListener;

        // Listen for comments
    }

    @Override
    public void onStop() {
        super.onStop();

        // Remove post value event listener
        if (mPostListener != null) {
            mPostReference.removeEventListener(mPostListener);
        }
    }
}
