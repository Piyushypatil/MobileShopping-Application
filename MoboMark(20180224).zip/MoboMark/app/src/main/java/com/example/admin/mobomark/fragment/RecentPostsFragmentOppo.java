package com.example.admin.mobomark.fragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public class RecentPostsFragmentOppo extends PostListFragment {

    public RecentPostsFragmentOppo() {}

    @Override
    public Query getQuery(DatabaseReference databaseReference) {
        // [START recent_Mobiles_query]
        // Last 100 Mobiles, these are automatically the 100 most recent
        // due to sorting by push() keys
        Query recentMobilesQuery = databaseReference.child("mobiles").child ("Oppo");
        // [END recent_Mobiles_query]

        return recentMobilesQuery;
    }
    @Override
    public String getBrand() {
        return "Oppo";
    }
}
