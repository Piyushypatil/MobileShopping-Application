package com.example.admin.mobomark.viewholder;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.mobomark.R;
import com.example.admin.mobomark.models.Samsung;
import com.example.admin.mobomark.models.Vivo;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

public class PostViewHolderSamsung extends RecyclerView.ViewHolder {

    public TextView titleView;
    public ImageView starView;
    public TextView numStarsView;
    public ImageView imageView;
    public TextView priceView;
    public ImageButton imageButton;

    public PostViewHolderSamsung(View itemView) {
        super(itemView);

        titleView = itemView.findViewById(R.id.post_title);
        starView = itemView.findViewById(R.id.star);
        numStarsView = itemView.findViewById(R.id.post_num_stars);
        imageView = itemView.findViewById(R.id.listImageView);
        priceView = itemView.findViewById(R.id.list_field_price);

    }

    public void bindToPost(final Context ctx, final Samsung post, View.OnClickListener starClickListener) {
        titleView.setText(post.brand+" "+post.model);
        numStarsView.setText(String.valueOf(post.starCount));
        priceView.setText(post.price);

        starView.setOnClickListener(starClickListener);

        Picasso.with(ctx).load(post.imageUrl).networkPolicy(NetworkPolicy.OFFLINE).into(imageView, new Callback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError() {
                Picasso.with(ctx).load(post.imageUrl).into(imageView);
            }
        });
    }

   // private void delbutton() {



}
