package com.example.admin.mobomark.fragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public class MyTopPostsFragment extends PostListFragment {

    public MyTopPostsFragment() {}

    @Override
    public Query getQuery(DatabaseReference databaseReference) {
        // [START my_top_Mobiles_query]
        // My top Mobiles by number of stars
        String myUserId = getUid();
        Query myTopMobilesQuery = databaseReference.child("mobiles").child("Oppo").orderByChild("starCount");
        // [END my_top_Mobiles_query]

        return myTopMobilesQuery;
    }

    @Override
    public String getBrand() {
        return "Oppo";
    }
}
