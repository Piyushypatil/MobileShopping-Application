package com.example.admin.mobomark.fragment;

import com.example.admin.mobomark.models.Post;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public class RecentPostsFragment extends PostListFragment {

    public RecentPostsFragment() {}

    @Override
    public Query getQuery(DatabaseReference databaseReference) {
        // [START recent_Mobiles_query]
        // Last 100 Mobiles, these are automatically the 100 most recent
        // due to sorting by push() keys
        Query recentMobilesQuery = databaseReference.child("mobiles");
        // [END recent_Mobiles_query]

        return recentMobilesQuery;
    }
}
