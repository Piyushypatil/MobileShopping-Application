package com.example.admin.mobomark.models;

import android.widget.EditText;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

// [START post_class]
@IgnoreExtraProperties
public class Lenovo {

    public String uid;
    public String brand;
    public String model;
    public String specs;
    public String cam;
    public String Sto;
    public String amazon;
    public String flipcart;
    public  String Shopclues;
    public  String Ebay;
    public  String Snapdeal;
    public String price;
    public String imageUrl;
    public String flipurl;
    public String amazonurl;
    public String Shopcluesurl;
    public String Ebayurl;
    public String Snapdealurl;
    public int starCount = 0;
    public Map<String, Boolean> stars = new HashMap<>();

    public Lenovo() {
        // Default constructor required for calls to DataSnapshot.getValue(Post.class)
    }

    public Lenovo(String uid, String brand, String model, String specs, String cam,String Sto, String price,String amazon,String flipcart,String Shopclues,String Ebay,String Snapdeal, String imageUrl,String flipurl,String amazonurl,String Shopcluesurl,String Ebayurl,String Snapdealurl) {
        this.uid = uid;
        this.brand = brand;
        this.model = model;
        this.specs = specs;
        this.cam = cam;
        this.Sto =Sto;
        this.amazon = amazon;
        this.flipcart = flipcart;
        this.Shopclues =Shopclues;
        this.Ebay=Ebay;
        this.Snapdeal=Snapdeal;
        this.price = price;
        this.imageUrl = imageUrl;
        this.flipurl = flipurl;
        this.amazonurl = amazonurl;
        this.Shopcluesurl =Shopcluesurl;
        this.Ebayurl = Ebayurl;
        this.Snapdealurl = Snapdealurl;
    }

    // [START post_to_map]
    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("uid", uid);
        result.put("brand",brand);
        result.put("model",model);
        result.put("specs",specs);
        result.put("cam",cam);
        result.put("Sto",Sto);
        result.put("price",price);
        result.put("amazon",amazon);
        result.put("flipcart",flipcart);
        result.put ("Shopclues",Shopclues);
        result.put("Ebay",Ebay);
        result.put("Snapdeal",Snapdeal);
        result.put("imageUrl",imageUrl);
        result.put ("flipurl",flipurl);
        result.put ("amazonurl",amazonurl);
        result.put ("Shopcluesurl",Shopcluesurl);
        result.put ("Ebayurl", Ebayurl);
        result.put ("Snapdealurl",Snapdealurl);
        result.put("starCount", starCount);
        result.put("stars", stars);

        return result;
    }
    // [END post_to_map]

}
// [END post_class]
