package com.example.admin.mobomark;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class WebShop extends AppCompatActivity {
    WebView webView;
    String Url;
    TextView t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_web_shop);
        Intent i3 = getIntent ( );
        t2 = (TextView) findViewById (R.id.TextUrl);
        t2.setText (i3.getExtras ( ).getString ("Shopcluesurl"));
        webView = (WebView) findViewById (R.id.myweb3);
        String Str1 = t2.getText ( ).toString ( );
        webView.getSettings ( ).setJavaScriptEnabled (true);
        webView.loadUrl (Str1);

        final Progress progress = new Progress (this);
        webView.setWebViewClient (new WebViewClient (){
            @Override
            public void onPageFinished(WebView view, String url) {
                progress.hideProgressDialog ();
                super.onPageFinished (view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progress.showProgressDialog ();
                super.onPageStarted (view, url, favicon);
            }
        });
    }
}
