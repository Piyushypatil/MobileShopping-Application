package com.example.admin.mobomark;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.TextView;

public class AllWeb extends AppCompatActivity {
    WebView webView;
    WebView webViewflip;
    WebView webViewsh;
    WebView webViewsn;
    WebView webVieweb;
    WebView webViewpt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_web);
        webView = (WebView) findViewById(R.id.myAll);
        webView.getSettings().setJavaScriptEnabled(true);
        String url = getIntent().getStringExtra("URL");
        webView.loadUrl(url);
    }
}
