package com.example.admin.mobomark;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

public class WebAmazon extends AppCompatActivity {
    WebView webView;
    String Url;
    TextView t2;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_web_amazon);
        Intent i2 = getIntent ( );
        t2 = (TextView) findViewById (R.id.TextUrl);
        t2.setText (i2.getExtras ( ).getString ("amazonurl"));
        webView = (WebView) findViewById (R.id.myweb2);
        String Str1 = t2.getText ( ).toString ( );
        webView.getSettings ( ).setJavaScriptEnabled (true);
        webView.loadUrl (Str1);

        final Progress progress = new Progress (this);
        webView.setWebViewClient (new WebViewClient (){
            @Override
            public void onPageFinished(WebView view, String url) {
                progress.hideProgressDialog ();
                super.onPageFinished (view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progress.showProgressDialog ();
                super.onPageStarted (view, url, favicon);
            }
        });
    }
}

