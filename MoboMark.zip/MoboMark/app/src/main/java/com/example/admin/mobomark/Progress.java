package com.example.admin.mobomark;

import android.app.ProgressDialog;
import android.content.Context;

/**
 * Created by admin on 20/02/2018.
 */

public class Progress {
    Context context;
    ProgressDialog progress;

    public Progress(Context context){
        this.context = context;
        progress = new ProgressDialog (context);
    }
    public void showProgressDialog(){
        if(progress != null ){
            progress.setCancelable (false);
            progress.setMessage ("Loading");
            progress.show ();
        }
    }

    public void hideProgressDialog(){
        if(progress.isShowing ()){
            progress.dismiss ();
        }
    }
}
