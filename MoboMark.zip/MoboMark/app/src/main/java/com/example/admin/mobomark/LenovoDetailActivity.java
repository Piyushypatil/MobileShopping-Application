package com.example.admin.mobomark;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.mobomark.models.Lenovo;
import com.example.admin.mobomark.models.Mobile;
import com.example.admin.mobomark.models.Moto;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class LenovoDetailActivity extends NewPostActivity {

    private static final String TAG = "LenovoDetailActivity";

    public static final String EXTRA_POST_KEY = "post_key";

    private DatabaseReference mPostReference;
    private DatabaseReference mCommentsReference;
    private ValueEventListener mPostListener;
    private String mPostKey;
    private ImageView imgv;
    private TextView mAuthorView;
    private TextView mTitleView;
    private TextView mBodyView;
    private TextView mBodyView1;
    private TextView mBodyView2;
    private TextView mPriceView;
    private TextView mAmazon;
    private TextView mFlipcart;
    private EditText mflipurl;
    private EditText mamazonurl;
    private EditText mCommentField;
    private Button mCommentButton;
    private RecyclerView mCommentsRecycler;
    ImageButton flipcart;
    ImageButton amazon;
    FloatingActionButton Save;
    ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vivo_detail);
        flipcart =(ImageButton)findViewById (R.id.flipcartImg);
        amazon =(ImageButton)findViewById (R.id.amazonImg);
        flipcart.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i= new Intent (LenovoDetailActivity.this,Web_Url.class);
                i.putExtra ("flipurl",mflipurl.getText ().toString ());
                startActivity (i);
            }
        });
        amazon.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Intent i2= new Intent (LenovoDetailActivity.this,WebAmazon.class);
                i2.putExtra ("amazonurl",mamazonurl.getText ().toString ());
                startActivity (i2);
            }
        });
        Save= (FloatingActionButton)findViewById (R.id.fabsave);
        Save.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {

                submitPost();
                Toast.makeText(LenovoDetailActivity.this, "update", Toast.LENGTH_LONG).show();


            }
        });
        // Get post key from intent
        mPostKey = getIntent().getStringExtra(EXTRA_POST_KEY);
        if (mPostKey == null) {
            throw new IllegalArgumentException("Must pass EXTRA_POST_KEY");
        }

        // Initialize Database
        mPostReference = FirebaseDatabase.getInstance().getReference()
                .child("Lenovo").child(mPostKey);

        // Initialize Views
        mTitleView = findViewById(R.id.post_title);
        mBodyView = findViewById(R.id.post_body);
        mBodyView1 = findViewById(R.id.post_body1);
        mBodyView2 = findViewById(R.id.post_body2);
        mAmazon = findViewById(R.id.post_AmazonPrice);
        mFlipcart = findViewById(R.id.post_FlipPrice);
        mPriceView = findViewById(R.id.post_price);
        mflipurl = findViewById (R.id.Url);
        mamazonurl = findViewById (R.id.url2);

        imgv = findViewById(R.id.imgv);
    }

    @Override
    public void onStart() {
        super.onStart();

        // Add value event listener to the post
        // [START post_value_event_listener]
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                Lenovo post = dataSnapshot.getValue(Lenovo.class);
                // [START_EXCLUDE]
                mTitleView.setText(post.brand+" "+post.model);
                mBodyView.setText(post.specs);
                mBodyView1.setText(post.cam);
                mBodyView2.setText(post.Sto);
                mAmazon.setText(post.amazon);
                mFlipcart.setText(post.flipcart);
                mPriceView.setText(post.price);
                mflipurl.setText(post.flipurl);
                mamazonurl.setText (post.amazonurl);

                Picasso.with(getApplicationContext()).load(post.imageUrl).into(imgv);
                // [END_EXCLUDE]
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
                // [START_EXCLUDE]
                Toast.makeText(LenovoDetailActivity.this, "Failed to load post.",
                        Toast.LENGTH_SHORT).show();
                // [END_EXCLUDE]
            }
        };
        mPostReference.addValueEventListener(postListener);
        // [END post_value_event_listener]

        // Keep copy of post listener so we can remove it when app stops
        mPostListener = postListener;

        // Listen for comments
    }

    @Override
    public void onStop() {
        super.onStop();

        // Remove post value event listener
        if (mPostListener != null) {
            mPostReference.removeEventListener(mPostListener);
        }
    }
}
