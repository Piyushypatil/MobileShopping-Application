package com.example.admin.mobomark;

import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.view.View;

import com.example.admin.mobomark.models.Mobile;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by admin on 24/02/2018.
 */

public class UpdatePrice {

    private Mobile mobile;

    public UpdatePrice(Mobile mobile) {
        this.mobile = mobile;

    }

    public void update(DatabaseReference ref, final View view){
        DatabaseReference mDatabase = ref;
        ref.setValue (mobile).addOnSuccessListener (new OnSuccessListener<Void> ( ) {
            @Override
            public void onSuccess(Void aVoid) {
                Snackbar.make (view,"Prices Updated Successfully",Snackbar.LENGTH_LONG).show ();
            }
        }).addOnFailureListener (new OnFailureListener ( ) {
            @Override
            public void onFailure(@NonNull Exception e) {
                Snackbar.make (view,"Error Occured",Snackbar.LENGTH_LONG).show ();

            }
        });
    }
}
