package com.example.admin.mobomark.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.admin.mobomark.PostDetailActivity;
import com.example.admin.mobomark.PostDetailActivityMoto;
import com.example.admin.mobomark.R;
import com.example.admin.mobomark.models.Mobile;
import com.example.admin.mobomark.models.Moto;
import com.example.admin.mobomark.viewholder.PostViewHolder;
import com.example.admin.mobomark.viewholder.PostViewHolderMoto;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Query;
import com.google.firebase.database.Transaction;

public abstract class PostListFragmentMoto extends Fragment {

    private static final String TAG = "MobileListFragmentMoto";
    ImageButton b1;
    // [START define_database_reference]
    private DatabaseReference mDatabase;
    // [END define_database_reference]

    private FirebaseRecyclerAdapter<Moto, PostViewHolderMoto> mAdapter;
    private RecyclerView mRecycler;
    private LinearLayoutManager mManager;

    public PostListFragmentMoto() {}

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container,
                              Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View rootView = inflater.inflate(R.layout.fragment_all_postsmoto, container, false);

        // [START create_database_reference]
        mDatabase = FirebaseDatabase.getInstance().getReference();
        // [END create_database_reference]

        mRecycler = rootView.findViewById(R.id.messages_list);
        mRecycler.setHasFixedSize(true);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Set up Layout Manager, reverse layout
        mManager = new LinearLayoutManager(getActivity());
        mManager.setReverseLayout(true);
        mManager.setStackFromEnd(true);
        mRecycler.setLayoutManager(mManager);

        // Set up FirebaseRecyclerAdapter with the Query
        Query MobilesQuery = getQuery(mDatabase);

        FirebaseRecyclerOptions options = new FirebaseRecyclerOptions.Builder<Moto>()
                .setQuery(MobilesQuery, Moto.class)
                .build();

        mAdapter = new FirebaseRecyclerAdapter<Moto, PostViewHolderMoto>(options) {

            @Override
            public PostViewHolderMoto onCreateViewHolder(ViewGroup parent, int viewType) {
                LayoutInflater inflater = LayoutInflater.from(parent.getContext());
                return new PostViewHolderMoto (inflater.inflate(R.layout.item_postmoto, parent, false));
            }

            @Override
            protected void onBindViewHolder(PostViewHolderMoto holder, int position, Moto model) {
                final DatabaseReference MobileRef = getRef(position);
                // Set click listener for the whole Mobile view
                final String MobileKey = MobileRef.getKey();
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Launch MobileDetailActivity
                        Intent intent = new Intent(getActivity(), PostDetailActivityMoto.class);
                        intent.putExtra(PostDetailActivityMoto.EXTRA_POST_KEY, MobileKey);
                        startActivity(intent);
                    }
                });
                holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
                        // set title
                        alertDialogBuilder.setTitle("Delete");
                        // set dialog message
                        alertDialogBuilder.setMessage("Are You Want To Delete").setCancelable(false).setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                MobileRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(getActivity(),"Mobile Deleted Successfully...",Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.cancel();
                                    }
                                });
                        // start dialoage Box
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        //show it
                        alertDialog.show();
                        return false;
                    }
                });

                // Determine if the current user has liked this Mobile and set UI accordingly
                if (model.stars.containsKey(getUid())) {
                    holder.starView.setImageResource(R.drawable.ic_toggle_star_24);
                } else {
                    holder.starView.setImageResource(R.drawable.ic_toggle_star_outline_24);
                }

                // Bind Mobile to ViewHolder, setting OnClickListener for the star button
                holder.bindToPost(getActivity(), model, new View.OnClickListener() {
                    @Override
                    public void onClick(View starView) {
                        // Need to write to both places the Mobile is stored
                        DatabaseReference globalMobileRef = mDatabase.child("Moto").child(MobileRef.getKey());
                        // Run two transactions
                        onStarClicked(globalMobileRef);

                    }
                });
            }

        };
        mRecycler.setAdapter(mAdapter);
    }




    // [START Mobile_stars_transaction]
    private void onStarClicked(DatabaseReference MobileRef) {
        MobileRef.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData mutableData) {
                Moto p = mutableData.getValue(Moto.class);
                if (p == null) {
                    return Transaction.success(mutableData);
                }

                if (p.stars.containsKey(getUid())) {
                    // Unstar the Mobile and remove self from stars
                    p.starCount = p.starCount - 1;
                    p.stars.remove(getUid());
                } else {
                    // Star the Mobile and add self to stars
                    p.starCount = p.starCount + 1;
                    p.stars.put(getUid(), true);
                }

                // Set value and report transaction success
                mutableData.setValue(p);
                return Transaction.success(mutableData);
            }

            @Override
            public void onComplete(DatabaseError databaseError, boolean b,
                                   DataSnapshot dataSnapshot) {
                // Transaction completed
                Log.d(TAG, "MobileTransaction:onComplete:" + databaseError);
            }
        });
    }
    // [END Mobile_stars_transaction]


    @Override
    public void onStart() {
        super.onStart();
        if (mAdapter != null) {
            mAdapter.startListening();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAdapter != null) {
            mAdapter.stopListening();
        }
    }


    public String getUid() {
        return FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    public abstract Query getQuery(DatabaseReference databaseReference);

}
