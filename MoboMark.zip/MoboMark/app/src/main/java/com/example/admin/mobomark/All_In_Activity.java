package com.example.admin.mobomark;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class All_In_Activity extends AppCompatActivity {
    ImageButton ama;
    ImageButton fli;
    ImageButton shop;
    ImageButton snap;
    ImageButton Ebay;
    ImageButton PyM;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all__in_);
        ama=(ImageButton)findViewById(R.id.linkAmazon);
        fli=(ImageButton)findViewById(R.id.linkFlipcart);
        shop=(ImageButton)findViewById(R.id.shop);
        snap=(ImageButton)findViewById(R.id.snap);
        Ebay =(ImageButton) findViewById (R.id.Ebay);
        PyM =(ImageButton) findViewById (R.id.myn);

        ama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(All_In_Activity.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.amazon.com");
                startActivity(webviewIntent);
            }
        });
        fli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(All_In_Activity.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.Flipkart.com");
                startActivity(webviewIntent);

            }
        });
        shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(All_In_Activity.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.shopclues.com");
                startActivity(webviewIntent);

            }
        });
        snap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(All_In_Activity.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.snapdeal.com");
                startActivity(webviewIntent);

            }
        });
        Ebay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(All_In_Activity.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.Ebay.com");
                startActivity(webviewIntent);

            }
        });
        PyM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent webviewIntent = new Intent(All_In_Activity.this,AllWeb.class);
                webviewIntent.putExtra("URL","http://www.Paytmmall.com");
                startActivity(webviewIntent);

            }
        });
    }
}
