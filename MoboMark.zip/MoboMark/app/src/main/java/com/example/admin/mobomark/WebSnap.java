package com.example.admin.mobomark;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class WebSnap extends AppCompatActivity {
    WebView webView;
    String Url;
    TextView t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_web_snap);
        Intent i5 = getIntent ( );
        t2 = (TextView) findViewById (R.id.TextUrl);
        t2.setText (i5.getExtras ( ).getString ("Snapdealurl"));
        webView = (WebView) findViewById (R.id.myweb5);
        String Str1 = t2.getText ( ).toString ( );
        webView.getSettings ( ).setJavaScriptEnabled (true);
        webView.loadUrl (Str1);

        final Progress progress = new Progress (this);
        webView.setWebViewClient (new WebViewClient (){
            @Override
            public void onPageFinished(WebView view, String url) {
                progress.hideProgressDialog ();
                super.onPageFinished (view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progress.showProgressDialog ();
                super.onPageStarted (view, url, favicon);
            }
        });
    }

}
