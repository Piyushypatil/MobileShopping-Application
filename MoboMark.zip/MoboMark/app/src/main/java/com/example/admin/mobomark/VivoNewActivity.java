package com.example.admin.mobomark;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.admin.mobomark.models.Lenovo;
import com.example.admin.mobomark.models.Mobile;
import com.example.admin.mobomark.models.Moto;
import com.example.admin.mobomark.models.User;
import com.example.admin.mobomark.models.Vivo;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class VivoNewActivity extends BaseActivity {
    private static final String TAG = "LenovoNewActivity";
    private static final String REQUIRED = "Required";

    // [START declare_database_ref]
    private DatabaseReference mDatabase;
    // [END declare_database_ref]

    private EditText mBrandField;
    private EditText mModelField;
    private EditText mFeaturesField;
    private EditText mCamField;
    private EditText mShopclues;
    private EditText mEbay;
    private EditText mSnapdeal;
    private EditText mAmazon;
    private EditText mFlip;
    private EditText mStorageFiled;
    private EditText mPriceField;
    public EditText mFlipurl;
    public EditText mAmazonurl;
    public EditText mShopcluesurl;
    public EditText mEbayurl;
    public EditText mSnapdealurl;
    private FloatingActionButton mSubmitButton;


    // Folder path for Firebase Storage.
    String Storage_Path = "All_Image_Uploads/";

    // Root Database Name for Firebase Database.
    String Database_Path = "All_Image_Uploads_Database";

    // Creating button.
    Button ChooseButton, UploadButton;

    // Creating EditText.
    EditText ImageName;

    // Creating ImageView.
    ImageView SelectImage;
    String imageUrl;
    // Creating URI.
    Uri FilePathUri;


    // Creating StorageReference and DatabaseReference object.
    StorageReference storageReference;
    DatabaseReference databaseReference;

    // Image request code for onActivityResult() .
    int Image_Request_Code = 7;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_vivo_new);


        // [START initialize_database_ref]
        mDatabase = FirebaseDatabase.getInstance ( ).getReference ( );
        // [END initialize_database_ref]

        mBrandField = findViewById (R.id.field_brand);
        mModelField = findViewById (R.id.field_model);
        mFeaturesField = findViewById (R.id.field_features);
        mCamField = findViewById (R.id.field_Cam);
        mStorageFiled = findViewById (R.id.field_Sto);
        mPriceField = findViewById (R.id.field_price);
        mSubmitButton = findViewById (R.id.fab_submit_post);
        mAmazon = findViewById (R.id.field_AmazonPrice);
        mFlip = findViewById (R.id.field_FlipPrice);
        mShopclues = findViewById (R.id.field_ShopPrice);
        mEbay = findViewById (R.id.field_EbayPrice);
        mSnapdeal = findViewById (R.id.field_SnapdealPrice);
        mFlipurl = findViewById (R.id.field_Flipurl);
        mAmazonurl = findViewById (R.id.field_Amazonurl);
        mShopcluesurl = findViewById (R.id.field_Shopcluesurl);
        mEbayurl = findViewById (R.id.field_Ebayurl);
        mSnapdealurl = findViewById (R.id.field_Snapdealurl);
        mSubmitButton.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {

                submitPost ( );
            }
        });


        // Assign FirebaseStorage instance to storageReference.
        storageReference = FirebaseStorage.getInstance ( ).getReference ( );

        // Assign FirebaseDatabase instance with root database name.
        databaseReference = FirebaseDatabase.getInstance ( ).getReference (Database_Path);

        //Assign ID'S to button.
        ChooseButton = (Button) findViewById (R.id.ButtonChooseImage);
        UploadButton = (Button) findViewById (R.id.ButtonUploadImage);
        // Assign ID's to EditText.
        ImageName = (EditText) findViewById (R.id.ImageNameEditText);

        // Assign ID'S to image view.
        SelectImage = (ImageView) findViewById (R.id.ShowImageView);

        // Assigning Id to ProgressDialog.
        progressDialog = new ProgressDialog (VivoNewActivity.this);

        // Adding click listener to Choose image button.
        ChooseButton.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {

                // Creating intent.
                Intent intent = new Intent ( );

                // Setting intent type as image to select image from phone storage.
                intent.setType ("image/*");
                intent.setAction (Intent.ACTION_GET_CONTENT);
                startActivityForResult (Intent.createChooser (intent, "Please Select Image"), Image_Request_Code);

            }
        });


        // Adding click listener to Upload image button.
        UploadButton.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {

                // Calling method to upload selected image on Firebase storage.
                UploadImageFileToFirebaseStorage ( );


            }
        });
    }
    void submitPost() {
        final String brand = mBrandField.getText ( ).toString ( );
        final String cam = mCamField.getText ( ).toString ( );
        final String Sto = mStorageFiled.getText ( ).toString ( );
        final String model = mModelField.getText ( ).toString ( );
        final String features = mFeaturesField.getText ( ).toString ( );
        final String amazon = "\u20B9 " + mAmazon.getText ( ).toString ( );
        final String flipcart = "\u20B9 " + mFlip.getText ( ).toString ( );
        final String Shopclues = "\u20B9 " + mShopclues.getText ( ).toString ( );
        final String Ebay = "\u20B9 " + mEbay.getText ( ).toString ( );
        final String Snapdeal = "\u20B9 " + mSnapdeal.getText ( ).toString ( );
        final String price = "\u20B9 " + mPriceField.getText ( ).toString ( );
        final String flipurl = mFlipurl.getText ( ).toString ( );
        final String Shopcluesurl = mShopcluesurl.getText ( ).toString ( );
        final String Ebayurl = mEbayurl.getText ( ).toString ( );
        final String Snapdealurl = mSnapdealurl.getText ( ).toString ( );
        final String amazonurl = mAmazonurl.getText ( ).toString ( );
        String TempImageName = ImageName.getText ( ).toString ( ).trim ( );

        if (!TempImageName.trim ( ).isEmpty ( )) {
            imageUrl = TempImageName;
        }
        // Title is required
        if (TextUtils.isEmpty (brand)) {
            mBrandField.setError (REQUIRED);
            return;
        }

        // Body is required
        if (TextUtils.isEmpty (model)) {
            mModelField.setError (REQUIRED);
            return;
        }

        Toast.makeText (this, "Posting...", Toast.LENGTH_SHORT).show ( );

        // [START single_value_read]
        final String userId = getUid ( );
        mDatabase.child ("users").child (userId).addListenerForSingleValueEvent (new ValueEventListener ( ) {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Get user value
                User user = dataSnapshot.getValue (User.class);

                // [START_EXCLUDE]
                if (user == null) {
                    // User is null, error out
                    Log.e (TAG, "User " + userId + " is unexpectedly null");
                    Toast.makeText (VivoNewActivity.this, "Error: could not fetch user.", Toast.LENGTH_SHORT).show ( );
                } else {
                    // Write new post
                    writeNewPost (userId, brand, model, features, cam, Sto, price, amazon, flipcart,Shopclues,Ebay,Snapdeal, imageUrl ,flipurl,amazonurl,Shopcluesurl,Ebayurl,Snapdealurl);
                }

                // Finish this Activity, back to the stream
                finish ( );
                // [END_EXCLUDE]
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w (TAG, "getUser:onCancelled", databaseError.toException ( ));
                // [START_EXCLUDE]
                // [END_EXCLUDE]
            }
        });
        // [END single_value_read]
    }

    // [START write_fan_out]
    private void writeNewPost(String userId, String brand, String model, String specs, String cam, String Sto, String price, String amazon, String flipcart, String Shopclues, String Ebay, String Snapdeal, String imageUrl,String flipurl,String amazonurl, String Shopcluesurl, String Ebayurl, String Snapdealurl) {
        // Create new post at /user-posts/$userid/$postid and at
        // /posts/$postid simultaneously
        String key = mDatabase.child ("Vivo").push ( ).getKey ( );
        Vivo post = new Vivo (userId, brand, model, specs, cam, Sto, price, amazon, flipcart,Shopclues,Ebay,Snapdeal, imageUrl,flipurl,amazonurl,Shopcluesurl,Ebayurl,Snapdealurl);
        Map<String, Object> postValues = post.toMap ( );

        Map<String, Object> childUpdates = new HashMap<> ( );
        childUpdates.put ("/Vivo/" + key, postValues);

        mDatabase.updateChildren (childUpdates);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult (requestCode, resultCode, data);

        if (requestCode == Image_Request_Code && resultCode == RESULT_OK && data != null && data.getData ( ) != null) {

            FilePathUri = data.getData ( );
            try {

                // Getting selected image into Bitmap.
                Bitmap bitmap = MediaStore.Images.Media.getBitmap (getContentResolver ( ), FilePathUri);

                // Setting up bitmap selected image into ImageView.
                SelectImage.setImageBitmap (bitmap);

                // After selecting image change choose button above text.
                ChooseButton.setText ("Image Selected");

            } catch (IOException e) {

                e.printStackTrace ( );
            }
        }
    }

    // Creating Method to get the selected image file Extension from File Path URI.
    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver ( );

        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton ( );

        // Returning the file Extension.
        return mimeTypeMap.getExtensionFromMimeType (contentResolver.getType (uri));

    }

    // Creating UploadImageFileToFirebaseStorage method to upload image on storage.
    public void UploadImageFileToFirebaseStorage() {

        // Checking whether FilePathUri Is empty or not.
        if (FilePathUri != null) {

            // Setting progressDialog Title.
            progressDialog.setTitle ("Image is Uploading...");

            // Showing progressDialog.
            progressDialog.show ( );
            // Checking whether FilePathUri Is empty or not.

            // Creating second StorageReference.
            StorageReference storageReference2nd = storageReference.child (Storage_Path + System.currentTimeMillis ( ) + "." + GetFileExtension (FilePathUri));

            // Adding addOnSuccessListener to second StorageReference.
            storageReference2nd.putFile (FilePathUri).addOnSuccessListener (new OnSuccessListener<UploadTask.TaskSnapshot> ( ) {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                    // Getting image name from EditText and store into string variable.
                    String TempImageName = ImageName.getText ( ).toString ( ).trim ( );

                    if (!TempImageName.trim ( ).isEmpty ( )) {
                        imageUrl = TempImageName;
                    }
                    // Hiding the progressDialog after done uploading.
                    progressDialog.dismiss ( );

                    imageUrl = String.valueOf (taskSnapshot.getDownloadUrl ( ));
                    // Showing toast message after done uploading.
                    Toast.makeText (getApplicationContext ( ), "Image Uploaded Successfully ", Toast.LENGTH_LONG).show ( );

                    @SuppressWarnings("VisibleForTests")

                    // Getting image upload ID.
                            String ImageUploadId = databaseReference.push ( ).getKey ( );

                    // Adding image upload id s child element into databaseReference.

                }
            })
                    // If something goes wrong .
                    .addOnFailureListener (new OnFailureListener ( ) {
                        @Override
                        public void onFailure(@NonNull Exception exception) {

                            // Hiding the progressDialog.
                            progressDialog.dismiss ( );

                            // Showing exception erro message.
                            Toast.makeText (VivoNewActivity.this, exception.getMessage ( ), Toast.LENGTH_LONG).show ( );
                        }
                    })

                    // On progress change upload time.
                    .addOnProgressListener (new OnProgressListener<UploadTask.TaskSnapshot> ( ) {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                            // Setting progressDialog Title.
                            progressDialog.setTitle ("Image is Uploading...");

                        }
                    });
        } else {

            Toast.makeText (VivoNewActivity.this, "Please Select Image or Add Image Name", Toast.LENGTH_LONG).show ( );

        }
    }
}
