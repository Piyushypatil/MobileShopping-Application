package com.example.admin.mobomark;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class Web_Url extends AppCompatActivity {
    WebView webView;
    String Url;
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_web__url);
        Intent i = getIntent ( );
        t1 = (TextView) findViewById (R.id.TextUrl);
        t1.setText (i.getExtras ( ).getString ("flipurl"));
        webView = (WebView) findViewById (R.id.myweb);
        String Str = t1.getText ( ).toString ( );
        webView.getSettings ( ).setJavaScriptEnabled (true);
        webView.loadUrl (Str);

        final Progress progress = new Progress (this);
        webView.setWebViewClient (new WebViewClient (){
            @Override
            public void onPageFinished(WebView view, String url) {
                progress.hideProgressDialog ();
                super.onPageFinished (view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progress.showProgressDialog ();
                super.onPageStarted (view, url, favicon);
            }
        });
    }
}